# Eye on Smishing - Smishing Analyzer
# A Social Engineering Defence Tool from the Cyber Garden Project

Clear-Host
Write-Host "`n[ Stage 1 ] Smishing Analysis" -ForegroundColor Cyan
Write-Host ""

# Find .txt file (excluding banner.txt)
$folderPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$txtFiles = Get-ChildItem -Path $folderPath -Filter *.txt | Where-Object { $_.Name -ne "banner.txt" }

if ($txtFiles.Count -eq 0) {
    Write-Host "No SMS message file found. Please place a .txt file (excluding 'banner.txt') in the same folder." -ForegroundColor Red
    Write-Host ""
    exit
}

# Load message content
$messageFile = $txtFiles[0].FullName
Write-Host "[  Alert  ] Loaded message from: $($txtFiles[0].Name)"
$message = Get-Content $messageFile -Raw

# Initialize score
$score = 0

# Define detection rules with expanded regex patterns
$rules = @(
    @{ Name = "Urgency or Threats"; Patterns = @("urgent(ly)?", "immediately", "act\s+now", "last\s+chance", "limited\s+time", "time\s+is\s+running", "final\s+warning") },
    @{ Name = "Prize or Free Offer"; Patterns = @("you[’']?ve\s+won", "congratulations", "free\s+(gift|offer|voucher)", "claim\s+(now|your\s+prize)", "lucky\s+winner", "exclusive\s+reward", "win\s+big") },
    @{ Name = "Account or Service Issues"; Patterns = @("account\s+(locked|suspended|blocked)", "verify\s+account", "reset\s+password", "unauthorized\s+login", "security\s+alert", "unusual\s+activity", "confirm\s+details") },
    @{ Name = "Bank or Financial Terms"; Patterns = @("bank\s+(account|statement|alert)", "credit\s+card", "debit\s+card", "transaction\s+alert", "payment\s+failure", "balance\s+check", "refund\s+processed") },
    @{ Name = "Suspicious or Shortened Links"; Patterns = @("http(s)?://(bit\.ly|tinyurl\.com|t\.co|shorturl|is\.gd|rb\.gy|.*\.ru/|.*\.tk/)") },
    @{ Name = "Requests for Personal Info"; Patterns = @("provide\s+(otp|password|credentials|security\s+code)", "confirm\s+ssn", "share\s+account\s+details", "login\s+info", "personal\s+data", "identity\s+verification") },
    @{ Name = "Refunds or Unauthorized Charges"; Patterns = @("you\s+have\s+been\s+(charged|billed)", "unauthorized\s+purchase", "refund\s+available", "payment\s+error", "billing\s+discrepancy", "chargeback\s+notice") },
    @{ Name = "Impersonation of Authority"; Patterns = @("irs", "police", "court\s+notice", "fbi", "gov(ernment)?", "official\s+warning", "legal\s+action") },
    @{ Name = "Poor Spelling or Grammar"; Patterns = @("recieve", "immediatly", "urgnt", "verfy", "confrim", "click\s+hear", "congrtulations", "plese\s+respond") },
    @{ Name = "Secrecy or Isolation Requests"; Patterns = @("don't\s+tell\s+anyone", "keep\s+this\s+secret", "do\s+not\s+share", "for\s+your\s+eyes\s+only", "only\s+you\s+can\s+access") }
)

# Evaluate rules
foreach ($rule in $rules) {
    $matched = $false
    foreach ($pattern in $rule.Patterns) {
        if ($message -match "(?i)$pattern") {
            $matched = $true
            break
        }
    }
    if ($matched) {
        Write-Host "[  Alert  ] Rule Triggered: $($rule.Name)" -ForegroundColor Yellow
        $score += 10
    }
}

# Stage 2: Result
Write-Host ""
Write-Host "[ Stage 2 ] Analysis Result" -ForegroundColor Cyan
Write-Host ""
Write-Host "[  Alert  ] Suspicion Score: $score`%"
Write-Host ""

if ($score -lt 20) {
    Write-Host "[  Alert  ] Risk Level: LOW RISK - Safe, but Remain Vigilant." -ForegroundColor Green
} elseif ($score -lt 40) {
    Write-Host "[  Alert  ] Risk Level: MEDIUM RISK - Potentially Suspicious. Please Verify the legitimacy." -ForegroundColor Yellow
} elseif ($score -lt 70) {
    Write-Host "[  Alert  ] Risk Level: HIGH RISK - Likely Smishing. Do Not interact." -ForegroundColor Magenta
} else {
    Write-Host "[  Alert  ] Risk Level: CRITICAL - Confirmed Smishing Attack. Take Immediate Action." -ForegroundColor Red
}

# Always show mitigations
Write-Host "`n[ Stage 3 ] Mitigation Methods" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. If the message claims to be from a known organization, contact organization through their official channel to confirm the email s legitimacy."
Write-Host "2. If the message includes a link, do not click it, scan it using Cyber Garden s online defensive tools first."
Write-Host "3. If the message contains an attachment or document, save it and scan it with a macro detector or trusted antivirus before opening."
Write-Host "4. Never reply to a text asking for personal or sensitive information unless you have verified the sender independently."
Write-Host "5. Do not install apps or open files that are linked or mentioned in suspicious messages."
Write-Host "6. Do not share passwords, bank details, or OTPs via text messages under any circumstances."
Write-Host "7. If a message uses threats, emotional pressure, or urgency to get information from you, do not respond."
Write-Host "8. Avoid acting on prize claims, refund offers, or urgent account alerts unless you have confirmed they are legitimate."
Write-Host "9. Report suspicious messages to your IT/security team, service provider, or relevant authority immediately."
Write-Host "10.Keep your mobile device and security apps updated, and help others recognize and report smishing attempts."
Write-Host ""