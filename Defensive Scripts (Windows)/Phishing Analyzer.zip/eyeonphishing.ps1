# Eye on Phishing - Phishing Analyzer
# A Social Engineering Defence Tool from the Cyber Garden Project

Clear-Host
Write-Host "`n[ Stage 1 ] Phishing Analysis" -ForegroundColor Cyan
Write-Host ""

# Search for .eml file
$folderPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$emlFiles = Get-ChildItem -Path $folderPath -Filter *.eml

if ($emlFiles.Count -eq 0) {
    Write-Host "[  Alert  ] No .eml file found. Please place a suspicious email (.eml) file in the same folder." -ForegroundColor Red
    exit
}

# Load EML content
$emailFile = $emlFiles[0].FullName
Write-Host "[  Alert  ] Loaded email from: $($emlFiles[0].Name)`n"
$emailContent = Get-Content $emailFile -Raw

# Initialize score
$score = 0

# 1. Header Authentication Failures - SPF/DKIM/DMARC must ALL be "pass"
$spfPass = $emailContent -match "(?i)spf=pass"
$dkimPass = $emailContent -match "(?i)dkim=pass"
$dmarcPass = $emailContent -match "(?i)dmarc=pass"

if (-not ($spfPass -and $dkimPass -and $dmarcPass)) {
    Write-Host "[ Warning ] Header Authentication Failed" -ForegroundColor Yellow
    $score += 40
}

# 2. Sender vs Reply-To mismatch using regex

# Side 1: smtp.mailfrom or From
$smtpFromMatch = [regex]::Match($emailContent, "(?i)smtp\.mailfrom=([^\s;>]+)")
$fromMatch = [regex]::Match($emailContent, "(?im)^From:\s*(?:.*<)?([^>]+)>?")

$senderAddress = ""
if ($smtpFromMatch.Success) {
    $senderAddress = $smtpFromMatch.Groups[1].Value.Trim()
} elseif ($fromMatch.Success) {
    $senderAddress = $fromMatch.Groups[1].Value.Trim()
}

# Side 2: Return-Path or Reply-To
$returnPathMatch = [regex]::Match($emailContent, "(?im)^Return-Path:\s*<([^>]+)>")
$replyToMatch = [regex]::Match($emailContent, "(?im)^Reply-To:\s*(?:.*<)?([^>]+)>?")

$envelopeAddress = ""
if ($returnPathMatch.Success) {
    $envelopeAddress = $returnPathMatch.Groups[1].Value.Trim()
} elseif ($replyToMatch.Success) {
    $envelopeAddress = $replyToMatch.Groups[1].Value.Trim()
}

# Compare both if available
if ($senderAddress -and $envelopeAddress -and ($senderAddress -ne $envelopeAddress)) {
    Write-Host "[ Warning ] Sender and Return Path Mismatch" -ForegroundColor Yellow
    $score += 10
}

# 3–12: Other Phishing Red Flags (7% each)
$rules = @(
    @{ Name = "Urgent Language or Threats"; Patterns = @("urgent", "immediately", "verify now", "action required", "suspend", "deactivate") },
    @{ Name = "Spoofed or Lookalike Domains"; Patterns = @("amaz0n", "paypa1", "micr0soft", "g00gle", "faceb00k") },
    @{ Name = "Deceptive Links"; Patterns = @("http[s]?:\/\/[^ ]+@[^ ]+", "url=.*@.*", "link=.*@.*") },
    @{ Name = "Unexpected Attachments"; Patterns = @(".zip", ".exe", ".scr", ".html", ".hta", ".js") },
    @{ Name = "Credential Harvesting Attempts"; Patterns = @("login", "verify account", "enter password", "credentials") },
    @{ Name = "Requests for Personal Information"; Patterns = @("ssn", "social security", "passport number", "bank details", "credit card") },
    @{ Name = "Poor Grammar or Spelling"; Patterns = @("immediatly", "acount", "verfy", "confrim", "informtion") },
    @{ Name = "Common Misleadings"; Patterns = @("you[’']?ve\s+won", "congratulations", "selected as winner", "exclusive offer") },
    @{ Name = "Generic Greetings"; Patterns = @("dear\s+(user|customer|sir|madam)", "valued\s+member") },
    @{ Name = "Fake Security Alerts"; Patterns = @("account\s+(compromised|locked|breached)", "security\s+alert", "unauthorized\s+login") }
)

foreach ($rule in $rules) {
    $triggered = $false
    foreach ($pattern in $rule.Patterns) {
        if ($emailContent -match "(?i)$pattern") {
            $triggered = $true
            break
        }
    }
    if ($triggered) {
        Write-Host "[  Alert  ] Rule Triggered: $($rule.Name)" -ForegroundColor Yellow
        $score += 5
    }
}

# Stage 2: Result
Write-Host ""
Write-Host "[ Stage 2 ] Analysis Result" -ForegroundColor Cyan
Write-Host ""
Write-Host "[  Alert  ] Suspicion Score: $score`%"
Write-Host ""

if ($score -lt 20) {
    Write-Host "[  Alert  ] Risk Level: LOW RISK - Safe, but Remain Vigilant." -ForegroundColor Green
} elseif ($score -lt 40) {
    Write-Host "[  Alert  ] Risk Level: MEDIUM RISK - Potentially Suspicious. Please Verify the Legitimacy." -ForegroundColor Yellow
} elseif ($score -lt 70) {
    Write-Host "[  Alert  ] Risk Level: HIGH RISK - Likely Phishing. Do Not Interact." -ForegroundColor Magenta
} else {
    Write-Host "[  Alert  ] Risk Level: CRITICAL - Confirmed Phishing Attack. Take Immediate Action." -ForegroundColor Red
}

# Always show mitigations
Write-Host ""
Write-Host "[ Stage 3 ] Mitigation Methods" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. If the email claims to be from a known organization, contact organization through their official channel to confirm the email s legitimacy."
Write-Host "2. If the email contains a link, do not click it right away. Scan it using Cyber Garden s online defensive tools. If flagged, do not visit it."
Write-Host "3. If the email includes any attachments, save them to your device and scan them using a macro detector or trusted antivirus before opening."
Write-Host "4. Do not share any personal or sensitive information through email until you have verified the sender s identity independently."
Write-Host "5. Do not download or run any file, form, or application from an email unless you are completely sure it is safe."
Write-Host "6. Never share banking details, passwords, or OTPs via email under any circumstances."
Write-Host "7. Do not respond to emails attempting to extract your sensitive information, even if they use threats, pressure, or blackmail tactics."
Write-Host "8. Do not trust emails with prize offers, urgent rewards, or financial demands unless you have confirmed the sender s legitimacy."
Write-Host "9. Report suspicious or uncomfortable emails to your IT department, manager, or relevant authorities immediately."
Write-Host "10.Keep your email app, antivirus, and device system updated, and help others understand how to spot phishing threats."
Write-Host ""
