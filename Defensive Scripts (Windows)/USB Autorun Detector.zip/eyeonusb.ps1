# Eye on USB - USB Autorun Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Management

function Get-UsbDriveLetters {
    $usbDrives = @()
    $usbDevices = Get-WmiObject Win32_DiskDrive | Where-Object { $_.InterfaceType -eq 'USB' }
    foreach ($device in $usbDevices) {
        $queryPartitions = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($device.DeviceID)'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
        $partitions = Get-WmiObject -Query $queryPartitions
        foreach ($partition in $partitions) {
            $queryLogical = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition"
            $logicalDisks = Get-WmiObject -Query $queryLogical
            foreach ($ld in $logicalDisks) {
                $usbDrives += $ld.DeviceID
            }
        }
    }
    return $usbDrives
}

function Disable-Device($deviceID) {
    $device = Get-WmiObject Win32_PnPEntity | Where-Object { $_.DeviceID -eq $deviceID }
    if ($device) {
        try {
            $null = $device.Disable()
            Write-Host "Device has been disabled successfully." -ForegroundColor Red
        } catch {
            Write-Host "Failed to disable the device. Try running this script as Administrator." -ForegroundColor DarkRed
        }
    } else {
        Write-Host "Could not locate device for disabling." -ForegroundColor DarkRed
    }
}

# Get current drive letters before insertion
$existingDrives = Get-UsbDriveLetters

# HID detection - Rewritten for proper blocking
$queryHID = "SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_PnPEntity' AND TargetInstance.PNPClass = 'HIDClass'"
$watcherHID = New-Object System.Management.ManagementEventWatcher $queryHID
$null = Register-ObjectEvent -InputObject $watcherHID -EventName "EventArrived" -Action {
    $device = $eventArgs.NewEvent.TargetInstance
    $name = $device.Name
    $id = $device.DeviceID

    Write-Host "`n[ Alert ] New HID Device or Bad USB Detected!" -ForegroundColor Yellow
    Write-Host "Name: $name"
    Write-Host "Device ID: $id"

    $result = [System.Windows.Forms.MessageBox]::Show(
        "New HID device or Bad USB detected. If you plugged a USB flash drive or storage device, this must be a Bad USB attack:`n$name`n`nDo you want to allow it?",
        "BadUSB Monitor",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )

    if ($result -eq [System.Windows.Forms.DialogResult]::No) {
        Disable-Device -deviceID $id
        Write-Host ""
        Write-Host "Close the program to exit..."
    } else {
        Write-Host "Device allowed by user." -ForegroundColor Green
        Write-Host ""
        Write-Host "Close the program to exit..."
    }
}

Write-Host "`n[ Stage 1 ] USB Guardian Activated. Waiting for new USB device." -ForegroundColor Cyan

# Watcher for any new USB-based DiskDrive device
$usbQuery = "SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_DiskDrive' AND TargetInstance.InterfaceType = 'USB'"
$usbWatcher = New-Object System.Management.ManagementEventWatcher $usbQuery
$null = Register-ObjectEvent -InputObject $usbWatcher -EventName "EventArrived" -Action {
    $usbDevice = $eventArgs.NewEvent.TargetInstance
    Write-Host "`n[  Alert  ] New USB device detected: $($usbDevice.Model)" -ForegroundColor Yellow
    Write-Host ""

    $queryPartitions = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($usbDevice.DeviceID)'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
    $partitions = Get-WmiObject -Query $queryPartitions

    foreach ($partition in $partitions) {
        $queryLogical = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition"
        $logicalDisks = Get-WmiObject -Query $queryLogical

        foreach ($ld in $logicalDisks) {
            $drive = $ld.DeviceID

            if ($existingDrives -notcontains $drive) {
                Write-Host "[ Stage 2 ] New drive letter assigned: $drive" -ForegroundColor Cyan
                Write-Host ""

                $infFiles = Get-ChildItem -Path $drive -Filter *.inf -ErrorAction SilentlyContinue
                $suspicious = $false

                if ($infFiles.Count -gt 0) {
                    foreach ($inf in $infFiles) {
                        Write-Host "[ Warning ] Autorun functionality detected: $($inf.Name)" -ForegroundColor Red
                        Write-Host ""
                    }
                    $suspicious = $true
                }

                $exeList = Get-ChildItem $drive -Filter *.exe -Recurse -ErrorAction SilentlyContinue
                foreach ($exe in $exeList) {
                    if ($exe.DirectoryName -eq $drive) {
                        Write-Host "[ Warning ] Executable in root detected: $($exe.Name)" -ForegroundColor Red
                        Write-Host ""
                        $suspicious = $true
                    }
                }

                if ($suspicious) {
                    $choice = [System.Windows.Forms.MessageBox]::Show(
                        "Auto-run or executable activity detected on USB $drive. Do you want to allow execution?",
                        "USB Guardian Alert",
                        [System.Windows.Forms.MessageBoxButtons]::YesNo,
                        [System.Windows.Forms.MessageBoxIcon]::Warning
                    )

                    if ($choice -eq "No") {
                        foreach ($inf in $infFiles) {
                            try {
                                Remove-Item $inf.FullName -Force
                                Write-Host "[  Alert  ] Autorun functionality removed: $($inf.Name)" -ForegroundColor Green
                                Write-Host ""
                            } catch {
                                Write-Host "[ Warning ] Failed to remove autorun functionality: $($inf.Name): $_" -ForegroundColor Red
                                Write-Host ""
                            }
                        }

                        $procs = Get-Process | Where-Object { $_.Path -like "$drive\*" }
                        foreach ($proc in $procs) {
                            try {
                                Stop-Process -Id $proc.Id -Force
                                Write-Host "[  Alert  ] Killed process: $($proc.Name)" -ForegroundColor Green
                                Write-Host ""
                            } catch {
                                Write-Host "[ Warning ] Failed to stop $($proc.Name)" -ForegroundColor Red
                                Write-Host ""
                            }
                        }
                        Write-Host "[ Stage 3 ] User denied autorun execution." -ForegroundColor Cyan
                        Write-Host ""
                        Write-Host "Close the program to exit..."
                    } else {
                        Write-Host "[ Stage 3 ] User allowed autorun execution." -ForegroundColor Cyan
                        Write-Host ""
                        Write-Host "Close the program to exit..."
                    }
                } else {
                    Write-Host "[ Stage 3 ] No autorun activity detected. USB device appears safe." -ForegroundColor Green
                    Write-Host ""
                    Write-Host "Close the program to exit..."
                }
            }
        }
    }
}

# Keep script running
  while ($true) {
    Start-Sleep -Seconds 1
  }