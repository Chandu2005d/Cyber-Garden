README MANUAL - CYBER GARDEN DEFENSIVE SCRIPTS (WINDOWS EDITION)
-----------------------------------------------------------------

1. Run the script by .bat file.

2. Run the .bat file as administrator to provide higher privileges.

3. If there is any suspicious program, review that well. If it is unknown, terminate it, else keep it after confirming the legitimacy.

 	- Option 1: [Recommended]
 		* Note down the PID value which is related to the suspicious process from the script output.
 		* Run the process terminator script which is from the Cyber Garden.
 		* Simply, type the noted PID and continue.
 		* Process will be terminated.

 	- Option 2:
 		* Note down the process name.
 		* Then search task manager on your windows search bar.
 		* Open the task manager.
 		* Explore processes.
 		* Find exact same process name that you marked as suspicious.
 		* Right click on the process and end the task.
 		* Process will be terminated.

4. If there is any malicious program, otherwise if it is well known or 100% verified, nothing to review, terminate it.

 		* Follow the same instructions above to terminate.

5. If there is any suspicious document, review that well. If it is unknown, delete it, else keep it after confirming the legitimacy.

 		* Scan results of the relevant scripts will include file locations of suspicious or malicious files.

6. If there is any malicious document, otherwise if it is well known or 100% verified, nothing to review, delete it.

7. For the Bad USB detector, Run the script first and then plug suspicious USB storage device

8. Before run the Macro File Detector, make sure you have proper internet connection.

9. For the phishing analyzer, put your email file that means .eml into the Phishing Analyzer folder.

 		* Download email from the mail application.
 		* Put the .eml file into the Phishing Analyzer folder.
 		* Run the script.

10.For the smishing analyzer put your suspicious message into message.txt inside the smishing analyzer folder.

11.For the vishing analyzer, provide accurate details and review the suspicious score and mitigation methods.

12.Find more information from the user manual on Cyber Garden official website.

13.Find user awareness sessions and video tutorials for the defensive scripts on Cyber Garden official website.

14.Stay tune with Cyber Garden.