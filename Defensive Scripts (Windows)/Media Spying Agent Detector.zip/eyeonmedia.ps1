# Eye on Media - Media Spying Agent Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

function Get-ProcessDetails {
    param($proc)
    try {
        $path = $null

        if ($proc.Path) {
            $path = $proc.Path
        } else {
            try {
                $p = Get-Process -Id $proc.Id -ErrorAction SilentlyContinue
                $path = $p.Path
            } catch {}

            if (-not $path) {
                try {
                    $path = (Get-Item "C:\Windows\System32\$($proc.Name).exe" -ErrorAction SilentlyContinue).FullName
                } catch {}
            }
        }

        $creation = "Unknown"
        if ($path) {
            try {
                $creation = (Get-Item $path -ErrorAction SilentlyContinue).CreationTime
            } catch {}
        }

        return @{ Name = $proc.Name; Id = $proc.Id; Path = $path; Created = $creation }

    } catch {
        return @{ Name = $proc.Name; Id = $proc.Id; Path = 'Unknown'; Created = 'Unknown' }
    }
}

# 1. Camera Access Detection
Write-Host "`n[ Stage 1 ] Scanning for programs accessing the camera." -ForegroundColor Cyan
Write-Host ""
$cameraRelated = Get-Process | Where-Object {
    $_.ProcessName -match 'camera|webcam|zoom|teams|skype|obs|discord|facetime|snapcam|virtualcamera|cam|spy|hide|hiding' -and
    $_.ProcessName -notmatch 'voicerecorder|soundrecorder|screenrecorder|audio|bandicam'
}

if ($cameraRelated) {
    foreach ($proc in $cameraRelated) {
        $info = Get-ProcessDetails -proc $proc
        Write-Host ("-> CAM Access: {0} (PID: {1})" -f $info.Name, $info.Id)
        Write-Host ("   Path: {0}" -f $info.Path)
        Write-Host ("   Created: {0}" -f $info.Created)
    }
} else {
    Write-Host "[  Alert  ] No camera access detected." -ForegroundColor Green
}

# 2. Microphone Access Detection
Write-Host "`n[ Stage 2 ] Scanning for programs accessing the microphone." -ForegroundColor Cyan
Write-Host ""
$audioRelated = Get-Process | Where-Object {
    $_.ProcessName -match 'zoom|teams|skype|discord|audacity|voicemeeter|mic|sound|record|spy|eavesdrop' -and
    $_.ProcessName -notmatch 'camera|video|screenrecorder|microsoft|microservices|camp|campus'
}

if ($audioRelated) {
    foreach ($proc in $audioRelated) {
        $info = Get-ProcessDetails -proc $proc
        Write-Host ("-> MIC Access: {0} (PID: {1})" -f $info.Name, $info.Id)
        Write-Host ("   Path: {0}" -f $info.Path)
        Write-Host ("   Created: {0}" -f $info.Created)
    }
} else {
    Write-Host "[  Alert  ] No microphone access detected." -ForegroundColor Green
}

# 3. Screen Recording Detection
Write-Host "`n[ Stage 3 ] Scanning for programs capable of screen recording." -ForegroundColor Cyan
Write-Host ""
$screenRelated = Get-Process | Where-Object {
    $_.ProcessName -match 'obs|camtasia|screenrec|snagit|bandicam|shadowplay|xsplit|record|screenshot|fraps|screen|spy|hide|hiding|look' -and
    $_.ProcessName -notmatch 'voicerecorder|audio|camera|video|smart'
}

if ($screenRelated) {
    foreach ($proc in $screenRelated) {
        $info = Get-ProcessDetails -proc $proc
        Write-Host ("-> SCREEN Access: {0} (PID: {1})" -f $info.Name, $info.Id)
        Write-Host ("   Path: {0}" -f $info.Path)
        Write-Host ("   Created: {0}" -f $info.Created)
    }
} else {
    Write-Host "[  Alert  ] No screen recording access detected." -ForegroundColor Green
}

Write-Host "`n[ Stage 4 ] Scan Complete." -ForegroundColor Cyan
Write-Host ""
