# Eye on Key - Key Logger Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

$procmonPath = Join-Path $PSScriptRoot "procmon.exe"
$filterPath = Join-Path $PSScriptRoot "filter.pmc"
$logPath = Join-Path $PSScriptRoot "procmon_log.pml"
$csvPath = Join-Path $PSScriptRoot "procmon_log.csv"

function Get-ModifyingProcess {
    param (
        [string]$targetFilePath,
        [string]$csvLogPath
    )

    try {
        $normalizedPath = ($targetFilePath -replace '[^\x20-\x7E]', '').ToLower().Trim()

        # Import CSV correctly (comma delimited, with quotes)
        $csvData = Import-Csv -Path $csvLogPath

        $match = $csvData | Where-Object {
            ($_.Operation -match "WriteFile") -and
            (($_.Path -replace '[^\x20-\x7E]', '').ToLower().Trim() -eq $normalizedPath)
        } | Sort-Object "Time of Day" -Descending | Select-Object -First 1

        if ($match) {
            return $match.'Process Name'
        } else {
            return "-"
        }
    }
    catch {
        return "-"
    }
}

# Set the folder(s) to monitor
$foldersToMonitor = @("$env:USERPROFILE")
$extensions = "*.txt", "*.log", "*.dat"

Write-Host "`n[Stage 1] Building Baseline ( Kindly wait while the operation completes. )" -ForegroundColor Cyan
Start-Sleep -Seconds 1

$baseline = @{}
foreach ($folder in $foldersToMonitor) {
    foreach ($ext in $extensions) {
        $files = Get-ChildItem -Path $folder -Recurse -Include $ext -ErrorAction SilentlyContinue
        foreach ($file in $files) {
            try {
                $baseline[$file.FullName] = @{
                    Size = $file.Length
                    Time = $file.LastWriteTime
                }
            } catch {}
        }
    }
}

# START PROCMON before user typing
Write-Host "`n[Stage 2] Typing Test 1" -ForegroundColor Cyan
Write-Host ""
Write-Host "Procmon Starting. Press RUN then YES to continue."

Start-Sleep -Seconds 3
Start-Process -FilePath $procmonPath -ArgumentList "/Quiet /Minimized /Backingfile `"$logPath`" /LoadConfig `"$filterPath`"" -WindowStyle Hidden
Start-Sleep -Seconds 2

Write-Host ""
Write-Host "Please type randomly on your keyboard for about 20 to 30 seconds."
Write-Host "Then press ENTER to continue."
$dummyInput = Read-Host "`n>>> Start typing now "

Write-Host ""
Write-Host "`n[Stage 2] Typing Test 2" -ForegroundColor Cyan
Write-Host ""
Write-Host "Please type randomly on your notepad for about 20 to 30 seconds."
Write-Host "Open notepad, type random text and return to the program."

Start-Sleep -Seconds 5
Write-Host ""
Write-Host "DISCLAIMER: For accurate detection, it is essential that you type into the notepad during this test." -ForegroundColor Magenta
$null = Read-Host "`n>>> Press ENTER once you're done with the notepad typing"

# STOP Procmon
Write-Host "`nStopping Procmon and exporting logs. Press YES to continue." -ForegroundColor Yellow
Stop-Process -Name procmon -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Start-Process -FilePath $procmonPath -ArgumentList "/Terminate" -NoNewWindow -Wait
Start-Process -FilePath $procmonPath -ArgumentList "/OpenLog `"$logPath`" /SaveAs `"$csvPath`"" -NoNewWindow -Wait
Start-Sleep -Seconds 2

# RECHECK file system for changes
Write-Host "`n[Stage 3] Scanning again for file changes. ( Kindly wait while the operation completes. )" -ForegroundColor Cyan
$log = @()
foreach ($folder in $foldersToMonitor) {
    foreach ($ext in $extensions) {
        $files = Get-ChildItem -Path $folder -Recurse -Include $ext -ErrorAction SilentlyContinue
        foreach ($file in $files) {
            try {
                $original = $baseline[$file.FullName]
                if ($null -ne $original) {
                    $newSize = $file.Length
                    $newTime = $file.LastWriteTime

                    if ($newSize -ne $original.Size -or $newTime -ne $original.Time) {
                        # Get modifying process using CSV log
                        $proc = Get-ModifyingProcess -targetFilePath $file.FullName -csvLogPath $csvPath

                        $log += [PSCustomObject]@{
                            FilePath         = $file.FullName
                            ChangedSize      = "$($original.Size) -> $newSize"
                            ChangedTime      = "$($original.Time) -> $newTime"
                            ModifiedByProcess= $proc
                        }
                    }
                }
            } catch {}
        }
    }
}

# Final output
if ($log.Count -eq 0) {
    Write-Host "`nNo suspicious file activity detected. No keylogger logs found." -ForegroundColor Green
    Write-Host ""
} else {
    Write-Host "`nWARNING: Potential keylogger activity detected:" -ForegroundColor Red
    $log | Format-Table FilePath, ChangedSize, ChangedTime, ModifiedByProcess -AutoSize
    Write-Host ""
}
