# Eye on Macro - Macro File Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

param (
    [string]$filePath
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonPath = Join-Path $scriptDir "python\python.exe"
$venvDir = Join-Path $scriptDir "venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"

# Step 1: Create venv if not already present
if (-Not (Test-Path $venvPython)) {
    Write-Host ""
    Write-Host "[  Alert  ] Creating isolated Python environment." -ForegroundColor Yellow
    Write-Host ""
    & $pythonPath -m venv $venvDir
    if (-Not (Test-Path $venvPython)) {
        Write-Host ""
        Write-Host "[ Warning ] Failed to create Python virtual environment." -ForegroundColor Red
        Write-Host ""
        exit 1
    }
}

# Step 2: Install oletools if not already installed
$pipCheck = & $venvPython -m pip show oletools 2>$null
if (-Not $pipCheck) {
    Write-Host ""
    Write-Host "[  Alert  ] Installing macro analysis tools." -ForegroundColor Yellow
    Write-Host ""
    & $venvPython -m pip install -r "$scriptDir\requirements.txt"
}

# Step 3: Scan the Office file using olevba
Write-Host "[  Alert  ] Scanning file: $filePath" -ForegroundColor Yellow
$oleOutput = & $venvPython -m oletools.olevba $filePath

# Step 4: Extract and display file metadata
$file = Get-Item $filePath
Write-Host ""
Write-Host "File Name:     $($file.Name)"
Write-Host "File Size:     $([math]::Round($file.Length / 1KB, 2)) KB"
Write-Host "File Location: $($file.FullName)"
Write-Host "Date Created:  $($file.CreationTime)"

# Step 5: Keyword-based macro analysis
$suspiciousKeywords = @(
    "CreateObject",
    "Shell",
    "WScript",
    "AutoOpen",
    "Base64String",
    "Execute",
    "Eval",
    "Environ",
    "PowerShell",
    "cmd.exe",
    "GetObject",
    "Run",
    "ADODB.Stream",
    "Scripting.FileSystemObject",
    "AppData",
    "ChrW",
    "StrReverse",
    "Sleep"
)

$severity = "Safe"
$matches = @()

foreach ($kw in $suspiciousKeywords) {
    if ($oleOutput -match "(?i)$kw") {
        $matches += $kw
    }
}

if ($matches.Count -gt 0) {
    $severity = "Malicious"
}

if ($severity -eq "Malicious") {
    Write-Host "Status:      " -NoNewline
    Write-Host "  Malicious" -ForegroundColor Red
    Write-Host "Suspicious Keywords: $($matches -join ', ')" -ForegroundColor DarkYellow
} else {
    Write-Host "Status:      " -NoNewline
    Write-Host "  Safe" -ForegroundColor Green
}
