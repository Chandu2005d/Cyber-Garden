# Eye on Location - Location Spying Agent Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

Write-Host "`n[ Stage 1 ] Searching for programs accessing device location.`n" -ForegroundColor Cyan

$dll = 'locationapi.dll'
$results = @()

Get-Process | ForEach-Object {
    try {
        foreach ($mod in $_.Modules) {
            if ($mod.ModuleName -ieq $dll) {
                $results += [PSCustomObject]@{
                    ProcessName = $_.ProcessName
                    PID = $_.Id
                    ModulePath = $mod.FileName
                }
            }
        }
    } catch {
        # Skip processes where module access is denied
    }
}

if ($results.Count -eq 0) {
    Write-Host "[  Alert  ] No processes currently using location APIs." -ForegroundColor Green
} else {
    $results | Sort-Object ProcessName | Format-Table -AutoSize
}

Write-Host "`n[ Stage 2 ] Scan complete." -ForegroundColor Cyan
Write-Host "`nPress ENTER to exit..."
Read-Host
