#!/bin/bash

# Eye on Location - Location Spying Agent Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# === Banner ===
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found."
fi

echo
echo "                   Eye on Location - Location Spying Agent Detector"
echo
echo "----------------------------------------------------------------------------------------"
echo

# === Colors ===
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
NC='\033[0m'

# === Pre-execution Instructions ===
echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Close ALL location-using apps (Maps, Browser, Weather, etc.) to reduce noise."
echo "2. Disable cloud sync or app tracking features if possible."
echo "3. Run this script with sudo/root for better access to system processes."
echo "4. Do not rename any of the program’s files."
echo "5. Detect unknown program accessing location, log details, then terminate the program."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."
clear

# === Stage 1: Search for location-accessing processes ===
echo -e "${CYAN}[ Stage 1 ] Searching for programs accessing device location.${NC}"
echo

# List of known location-related process name patterns
location_keywords="geoclue|maps|weather|gps|location|tracker|geoservice|navigator|navigation|find|locate|track"

# List of exclusions to skip
exclude_keywords="eyeonlocation"

# Flag to track if anything is detected
found_location_access=0

# Check processes
ps -eo pid,comm --no-headers | while read -r pid pname; do
    if [[ "$pname" =~ $location_keywords && ! "$pname" =~ $exclude_keywords ]]; then
        exe_path=$(readlink -f "/proc/$pid/exe" 2>/dev/null || echo "Unknown")
        echo "-> Detected Location Access:"
        echo "   Process: $pname (PID: $pid)"
        echo "   Path: $exe_path"
        echo
        found_location_access=1
    fi
done

# If no matching process was found
if [[ $found_location_access -eq 0 ]]; then
    echo -e "${GREEN}[  Alert  ] No processes currently using location services.${NC}"
fi

# === Additional Check: GNOME Geolocation service (Geoclue) ===
if pgrep -x "geoclue" &>/dev/null; then
    echo -e "\n[ Info ] Geoclue location service is running."
    echo "-> Check app permissions using your system's privacy settings."
fi

# === Stage 2: Scan Complete ===
echo
echo -e "${CYAN}[ Stage 2 ] Scan complete.${NC}"
echo
read -p "Press ENTER to exit..."
