#!/bin/bash

# Eye on Phishing - Phishing Analyzer
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# Load banner from local file
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found!"
fi

echo
echo "                          Eye on Phishing - Phishing Analyzer"
echo
echo "----------------------------------------------------------------------------------------"
echo

# Yellow colored instructions
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
NC='\033[0m'

echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Put suspicious email file into the folder as .eml file."
echo "2. Close ALL running applications and background programs to reduce noise."
echo "3. Disable automatic cloud sync or backup software temporarily."
echo "4. Run this script with sudo/root privileges for full system access."
echo "5. Do not modify any file name related to the program."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."

clear

# === Stage 1: Analysis ===
echo -e "${CYAN}[ Stage 1 ] Phishing Analysis${NC}"
echo

# Look for .eml file in current directory
eml_file=$(find "$SCRIPT_DIR" -maxdepth 1 -iname "*.eml" | head -n 1)

if [[ -z "$eml_file" ]]; then
    echo -e "\033[1;31m[  Alert  ] No .eml file found. Please place a suspicious email (.eml) file in the same folder.\033[0m"
    exit 1
fi

echo -e "[  Alert  ] Loaded email from: $(basename "$eml_file")"
echo

email_content=$(cat "$eml_file")
score=0

# Header Auth Checks
spf=$(echo "$email_content" | grep -i "spf=pass")
dkim=$(echo "$email_content" | grep -i "dkim=pass")
dmarc=$(echo "$email_content" | grep -i "dmarc=pass")

if [[ -z "$spf" || -z "$dkim" || -z "$dmarc" ]]; then
    echo -e "\033[1;33m[ Warning ] Header Authentication Failed\033[0m"
    score=$((score + 40))
fi

# Sender vs Reply-To mismatch
sender=$(echo "$email_content" | grep -i -m1 "^From:" | grep -oP "<\K[^>]+")
replyto=$(echo "$email_content" | grep -i -m1 "^Reply-To:" | grep -oP "<\K[^>]+")
returnpath=$(echo "$email_content" | grep -i -m1 "^Return-Path:" | grep -oP "<\K[^>]+")
envelope="${replyto:-$returnpath}"

if [[ -n "$sender" && -n "$envelope" && "$sender" != "$envelope" ]]; then
    echo -e "\033[1;33m[ Warning ] Sender and Return Path Mismatch\033[0m"
    score=$((score + 10))
fi

# Rule Triggers
declare -A rules
rules=(
    ["Urgent Language or Threats"]="urgent|immediately|verify now|action required|suspend|deactivate"
    ["Spoofed or Lookalike Domains"]="amaz0n|paypa1|micr0soft|g00gle|faceb00k"
    ["Deceptive Links"]="http[s]?:\/\/[^ ]+@[^ ]+|url=.*@.*|link=.*@.*"
    ["Unexpected Attachments"]=".zip|.exe|.scr|.html|.hta|.js"
    ["Credential Harvesting Attempts"]="login|verify account|enter password|credentials"
    ["Requests for Personal Information"]="ssn|social security|passport number|bank details|credit card"
    ["Poor Grammar or Spelling"]="immediatly|acount|verfy|confrim|informtion"
    ["Common Misleadings"]="you[’']?ve won|congratulations|selected as winner|exclusive offer"
    ["Generic Greetings"]="dear (user|customer|sir|madam)|valued member"
    ["Fake Security Alerts"]="account (compromised|locked|breached)|security alert|unauthorized login"
)

for rule in "${!rules[@]}"; do
    if echo "$email_content" | grep -Eiq "${rules[$rule]}"; then
        echo -e "\033[1;33m[  Alert  ] Rule Triggered: $rule\033[0m"
        score=$((score + 5))
    fi
done

# === Stage 2: Result ===
echo
echo -e "${CYAN}[ Stage 2 ] Analysis Result${NC}"
echo
echo -e "[  Alert  ] Suspicion Score: $score%"

if ((score < 20)); then
    echo -e "\033[1;32m[  Alert  ] Risk Level: LOW RISK - Safe, but Remain Vigilant.\033[0m"
elif ((score < 40)); then
    echo -e "\033[1;33m[  Alert  ] Risk Level: MEDIUM RISK - Potentially Suspicious. Please Verify the Legitimacy.\033[0m"
elif ((score < 70)); then
    echo -e "\033[1;35m[  Alert  ] Risk Level: HIGH RISK - Likely Phishing. Do Not Interact.\033[0m"
else
    echo -e "\033[1;31m[  Alert  ] Risk Level: CRITICAL - Confirmed Phishing Attack. Take Immediate Action.\033[0m"
fi

# === Stage 3: Mitigation Methods ===
echo
echo -e "${CYAN}[ Stage 3 ] Mitigation Methods${NC}"
echo
cat << EOF
1. Contact the organization via their official channels to verify the email's legitimacy.
2. Do not click any links. Scan them using Cyber Garden’s online tools or a trusted scanner.
3. Save and scan all attachments using a macro detector or antivirus before opening.
4. Do not share personal/sensitive info without verifying sender identity.
5. Avoid executing any file/form/application from suspicious emails.
6. Never share banking details, OTPs, or passwords via email.
7. Do not respond to emails that use threats, pressure, or blackmail.
8. Be skeptical of prize offers, rewards, or financial demands.
9. Report suspicious emails to IT/security teams or proper authorities.
10.Keep your email client, antivirus, and OS updated regularly.
EOF

echo
read -p "Press ENTER to exit..."
