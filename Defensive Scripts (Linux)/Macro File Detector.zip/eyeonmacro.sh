#!/bin/bash

# Eye on Macro - Macro File Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# Load the banner from the same directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found!"
fi

echo
echo "                             Eye on Macro - Macro File Detector"
echo
echo "----------------------------------------------------------------------------------------"
echo

# Colored warning using ANSI escape codes
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Disconnect all network connections to avoid external interference."
echo "2. Close ALL running applications and background processes to reduce noise."
echo "3. Disable automatic cloud sync or backup services temporarily."
echo "4. Run this script with sudo/root privileges for full system access."
echo "5. Do not rename any file related to this tool."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."

clear

# Detection Logic
echo "[ Stage 1 ] Scanning for potentially malicious macro files."
echo

# Detect suspicious macro-embedded Office documents
find "$HOME" -type f \( -iname "*.docm" -o -iname "*.xlsm" -o -iname "*.pptm" \) | while read -r file; do
    echo "[+] Found macro-enabled file: $file"
    if strings "$file" | grep -Eqi "(AutoOpen|Shell|CreateObject|WScript|ExecuteGlobal|Base64|powershell|cmd\.exe)"; then
        echo "    -> [!] Suspicious macro behavior detected in: $file"
    else
        echo "    -> [OK] No obvious malicious macro indicators found."
    fi
done

# Alert if LibreOffice or OpenOffice documents contain embedded scripts/macros
echo
echo "Scanning for script-embedded ODF files"
find "$HOME" -type f \( -iname "*.odt" -o -iname "*.ods" -o -iname "*.odp" \) | while read -r odf_file; do
    if unzip -l "$odf_file" | grep -q "Basic"; then
        echo "[!] Embedded macro/scripts found in: $odf_file"
    fi
done

echo
echo "----------------------------------------------------------------------------------------"
echo "Scan complete. Review the flagged files above with caution."
echo
