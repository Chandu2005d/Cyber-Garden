#!/bin/bash

# Eye on Media - Media Spying Agent Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# === Banner ===
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found."
fi

echo
echo "                      Eye on Media - Media Spying Agent Detector"
echo
echo "----------------------------------------------------------------------------------------"
echo

# === Colors ===
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
NC='\033[0m'

# === Instructions ===
echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Disconnect all network connections to avoid external interference."
echo "2. Close ALL running applications and background processes to reduce noise."
echo "3. Disable automatic cloud sync or backup software temporarily."
echo "4. Run this script with sudo/root privileges for complete detection."
echo "5. Do not rename any of the program’s files."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."
clear

# === Function to Get Process Info ===
get_process_info() {
    local pid="$1"
    local name="$2"
    local exe_path created_at

    if [[ -e "/proc/$pid/exe" ]]; then
        exe_path=$(readlink -f "/proc/$pid/exe")
    else
        exe_path="Unknown"
    fi

    if [[ -e "$exe_path" ]]; then
        created_at=$(stat -c %y "$exe_path" 2>/dev/null)
    else
        created_at="Unknown"
    fi

    echo "-> $3 Access: $name (PID: $pid)"
    echo "   Path: $exe_path"
    echo "   Created: $created_at"
}

# === Stage 1: Camera Access Detection ===
echo -e "${CYAN}[ Stage 1 ] Scanning for programs accessing the camera.${NC}"
echo

camera_keywords="camera|webcam|zoom|teams|skype|obs|discord|facetime|snapcam|virtualcamera|cam|spy|hide|hiding"
camera_exclude="voicerecorder|soundrecorder|screenrecorder|audio|bandicam"

found_camera=0
ps -eo pid,comm --no-header | while read -r pid pname; do
    if [[ "$pname" =~ $camera_keywords && ! "$pname" =~ $camera_exclude ]]; then
        get_process_info "$pid" "$pname" "CAM"
        found_camera=1
    fi
done

if [[ $found_camera -eq 0 ]]; then
    echo -e "${GREEN}[  Alert  ] No camera access detected.${NC}"
fi

# === Stage 2: Microphone Access Detection ===
echo
echo -e "${CYAN}[ Stage 2 ] Scanning for programs accessing the microphone.${NC}"
echo

mic_keywords="zoom|teams|skype|discord|audacity|voicemeeter|mic|sound|record|spy|eavesdrop"
mic_exclude="camera|video|screenrecorder|microsoft|microservices|camp|campus"

found_mic=0
ps -eo pid,comm --no-header | while read -r pid pname; do
    if [[ "$pname" =~ $mic_keywords && ! "$pname" =~ $mic_exclude ]]; then
        get_process_info "$pid" "$pname" "MIC"
        found_mic=1
    fi
done

if [[ $found_mic -eq 0 ]]; then
    echo -e "${GREEN}[  Alert  ] No microphone access detected.${NC}"
fi

# === Stage 3: Screen Recording Detection ===
echo
echo -e "${CYAN}[ Stage 3 ] Scanning for programs capable of screen recording.${NC}"
echo

screen_keywords="obs|camtasia|screenrec|snagit|bandicam|shadowplay|xsplit|record|screenshot|fraps|screen|spy|hide|hiding|look"
screen_exclude="voicerecorder|audio|camera|video|smart"

found_screen=0
ps -eo pid,comm --no-header | while read -r pid pname; do
    if [[ "$pname" =~ $screen_keywords && ! "$pname" =~ $screen_exclude ]]; then
        get_process_info "$pid" "$pname" "SCREEN"
        found_screen=1
    fi
done

if [[ $found_screen -eq 0 ]]; then
    echo -e "${GREEN}[  Alert  ] No screen recording access detected.${NC}"
fi

# === Stage 4: Completion ===
echo
echo -e "${CYAN}[ Stage 4 ] Scan Complete.${NC}"
echo
read -p "Press ENTER to exit..."
