#!/bin/bash

# Eye on Vishing - Vishing Analyzer
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# Load banner
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found!"
fi

echo
echo "                          Eye on Vishing - Vishing Analyzer"
echo
echo "----------------------------------------------------------------------------------------"
echo

# Colored output
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
MAGENTA='\033[1;35m'
RED='\033[1;31m'
CYAN='\033[1;36m'
NC='\033[0m'

# Pre-execution instructions
echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Disconnect all network connections to avoid external interference."
echo "2. Close ALL running applications and background programs to reduce noise."
echo "3. Disable automatic cloud sync or backup software temporarily."
echo "4. Run this script with sudo/root privileges for full system access."
echo "5. Do not modify any file name related to the program."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."
clear

# Stage 1: Analysis
echo -e "${CYAN}[ Stage 1 ] Vishing Analysis${NC}"
echo
echo "Please answer each question:"
echo "Type Y for Yes, N for No"
echo

score=0

# Questions 1-5 (10% each)
for i in {1..5}; do
    case $i in
        1) echo "1. Was the call or voice message unexpected?" ;;
        2) echo "2. Did the message involve any form of urgency?" ;;
        3) echo "3. Did the caller pressure you to take immediate action?" ;;
        4) echo "4. Were you asked to visit a website or open a document during the call?" ;;
        5) echo "5. Did the caller ask for sensitive personal information?" ;;
    esac

    read -p "Answer [Y/N]: " input
    if [[ "$input" =~ ^[Yy]$ ]]; then
        score=$((score + 10))
    fi
    echo
done

# Questions 6–15 (5% each)
for i in {6..15}; do
    case $i in
        6) echo "6. Did the caller pretend to represent a well-known organization?" ;;
        7) echo "7. Did the caller avoid giving verifiable contact information?" ;;
        8) echo "8. Was the call made through a spoofed or unknown number?" ;;
        9) echo "9. Did the caller ask you to install any apps or remote tools?" ;;
        10) echo "10. Did the tone include threats, intimidation, or manipulation?" ;;
        11) echo "11. Did the caller discourage verifying the message or contacting others?" ;;
        12) echo "12. Did the caller offer unusually generous benefits or gifts?" ;;
        13) echo "13. Did the caller use broken, strange, or robotic language?" ;;
        14) echo "14. Was there delay, echo, or scripted behavior in the call?" ;;
        15) echo "15. Did the caller reference private info you haven't shared publicly?" ;;
    esac

    read -p "Answer [Y/N]: " input
    if [[ "$input" =~ ^[Yy]$ ]]; then
        score=$((score + 5))
    fi
    echo
done

# Stage 2: Result
echo -e "${CYAN}[ Stage 2 ] Analysis Result${NC}"
echo
echo "[  Alert  ] Suspicion Score: $score%"

if ((score < 20)); then
    echo -e "${GREEN}[  Alert  ] Risk Level: LOW RISK${NC}"
    echo "Safe, but Remain Vigilant."
elif ((score < 40)); then
    echo -e "${YELLOW}[  Alert  ] Risk Level: MEDIUM RISK${NC}"
    echo "Potentially Suspicious. Please Verify the Legitimacy."
elif ((score < 70)); then
    echo -e "${MAGENTA}[  Alert  ] Risk Level: HIGH RISK${NC}"
    echo "Likely Vishing. Do Not Interact."
else
    echo -e "${RED}[  Alert  ] Risk Level: CRITICAL${NC}"
    echo "Confirmed Vishing Attack. Take Immediate Action."
fi

# Stage 3: Mitigation Methods
echo
echo -e "${CYAN}[ Stage 3 ] Mitigation Methods${NC}"
echo
cat << EOF
1. If the caller claims to be from a known organization, hang up and call the organization directly using their official number.
2. If a link is shared via call, message, or voicemail, do not open it. Use Cyber Garden’s link detection tools to scan it first.
3. If you're sent any document during or after the call, save it and scan it with a macro detector or antivirus before opening.
4. Never share personal or sensitive information over the phone unless you have verified the caller's identity independently.
5. Do not install or run any software or mobile apps suggested by unknown callers.
6. Do not disclose passwords, OTPs, banking info, or any security credentials over the phone.
7. If the caller uses threats, emotional pressure, or blackmail, do not respond — end the call immediately.
8. Do not fall for limited-time offers, prize claims, or urgent demands without verifying the caller's legitimacy.
9. Report suspicious calls or voice messages to your IT/security team, manager, or local authorities.
10. Keep your phone and security apps updated, and help others recognize and report vishing attempts.
EOF

echo
read -p "Press ENTER to exit..."
