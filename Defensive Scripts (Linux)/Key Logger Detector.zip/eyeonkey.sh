#!/bin/bash

# Eye on Key - Key Logger Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

# =================== CONFIG ===================
TARGET_DIR="$HOME"
EXTENSIONS=("*.txt" "*.log" "*.dat")
TMP_BASELINE="/tmp/eyeonkey_baseline.tmp"
TMP_RESCAN="/tmp/eyeonkey_rescan.tmp"
BANNER_FILE="$(dirname "$0")/banner.txt"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# =================== BANNER ===================
clear
if [[ -f "$BANNER_FILE" ]]; then
  cat "$BANNER_FILE"
else
  echo -e "${YELLOW}[!] Warning: banner.txt not found in script directory.${NC}"
fi

echo -e "${CYAN}\n                        Eye on Key - Key Logger Detector${NC}"
echo -e "\n----------------------------------------------------------------------------------------\n"
echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}\n"
echo "1. Disconnect all network connections to avoid external interference."
echo "2. Close ALL running applications and background programs to reduce noise."
echo "3. Disable automatic cloud sync or backup software temporarily."
echo "4. Make sure you run this script as ROOT for full system access."
echo "5. Do not modify any file name related to the program."
echo
read -rp "Press ENTER to confirm you have completed these steps and want to proceed..."
clear

# =================== VALIDATE ===================
if [[ ! -d "$TARGET_DIR" ]]; then
  echo -e "${RED}[ERROR] Target directory does not exist: $TARGET_DIR${NC}"
  exit 1
fi

# =================== PHASE 1: BASELINE ===================
echo -e "\n${CYAN}[Stage 1] Scanning and building file baseline.${NC}"
sleep 1

> "$TMP_BASELINE"
for ext in "${EXTENSIONS[@]}"; do
  find "$TARGET_DIR" -type f -name "$ext" 2>/dev/null | while read -r file; do
    [[ -f "$file" ]] || continue
    size=$(stat -c %s "$file" 2>/dev/null)
    mod_time=$(stat -c %Y "$file" 2>/dev/null)
    [[ -n "$size" && -n "$mod_time" ]] && echo "$file|$size|$mod_time" >> "$TMP_BASELINE"
  done
done

file_count=$(wc -l < "$TMP_BASELINE")
echo "→ $file_count files monitored."

# =================== PHASE 2: TYPING TEST ===================
echo -e "\n${YELLOW}[Stage 2] Keyboard typing detection phase.${NC}"
echo -e "→ First, type randomly here in the terminal for 20 seconds."
read -rp ">>> Start Typing. At the end press ENTER."
sleep 2

echo -e "\n→ Now open a text editor, type randomly, and save nothing."
echo -e "${YELLOW}DISCLAIMER: This is important to separate real from hidden logging.${NC}"
read -rp ">>> Press ENTER once you're done with typing in the editor."

# =================== PHASE 3: RESCAN ===================
echo -e "\n${CYAN}[Stage 3] Rechecking files for stealthy modifications.${NC}"
sleep 1

> "$TMP_RESCAN"
for ext in "${EXTENSIONS[@]}"; do
  find "$TARGET_DIR" -type f -name "$ext" 2>/dev/null | while read -r file; do
    [[ -f "$file" ]] || continue
    size=$(stat -c %s "$file" 2>/dev/null)
    mod_time=$(stat -c %Y "$file" 2>/dev/null)
    [[ -n "$size" && -n "$mod_time" ]] && echo "$file|$size|$mod_time" >> "$TMP_RESCAN"
  done
done

# =================== PHASE 4: COMPARE ===================
echo -e "\n${YELLOW}[Results] Scanning for potential keylog file changes.${NC}"
sleep 1

changes=0

while IFS= read -r line; do
  IFS='|' read -r file_old size_old time_old <<< "$line"
  [[ -z "$file_old" ]] && continue

  match=$(grep -F "$file_old|" "$TMP_RESCAN")
  if [[ -n "$match" ]]; then
    IFS='|' read -r _ size_new time_new <<< "$match"

    if [[ "$size_old" != "$size_new" || "$time_old" != "$time_new" ]]; then
      echo -e "${RED}[SUSPICIOUS] File changed: $file_old${NC}"
      echo "            Size: $size_old → $size_new"
      echo "            Time: $(date -d @$time_old) → $(date -d @$time_new)"
      echo
      ((changes++))
    fi
  fi
done < "$TMP_BASELINE"

# =================== CLEANUP ===================
rm -f "$TMP_BASELINE" "$TMP_RESCAN"

if [[ $changes -eq 0 ]]; then
  echo -e "${GREEN}[OK] No suspicious file changes detected. No keylogger logs found.${NC}"
else
  echo -e "${RED}[!] $changes suspicious file(s) detected. Potential keylogger activity.${NC}"
fi

echo -e "\n-------------------------------------------------------------------"
read -rp "Press ENTER to exit..."
