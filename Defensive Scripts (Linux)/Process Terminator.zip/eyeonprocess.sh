#!/bin/bash

# Eye on Process - Process Terminator
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# === Load Banner ===
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found."
fi

echo
echo "                          Eye on Process - Process Terminator"
echo
echo "----------------------------------------------------------------------------------------"
echo

# === Colors ===
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
NC='\033[0m'

# === Instructions ===
echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Close ALL running applications and background programs to reduce noise."
echo "2. Disable automatic cloud sync or backup software temporarily."
echo "3. Run this script with sudo/root privileges for full system access."
echo "4. Do not modify any file name related to the program."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."
clear

# === Prompt for PID ===
read -p "Enter the PID of the process to terminate: " PID
echo

if [[ ! "$PID" =~ ^[0-9]+$ ]]; then
    echo -e "${RED}[ Error ] Invalid PID. Please enter a numeric value.${NC}"
    echo
    read -p "Press ENTER to exit..."
    exit 1
fi

# === Attempt to Kill the Process ===
kill -9 "$PID" >/dev/null 2>&1

if [[ $? -eq 0 ]]; then
    echo
    echo -e "${GREEN}Process with PID $PID terminated successfully.${NC}"
    echo
else
    echo
    echo -e "${RED}Failed to terminate process with PID $PID.${NC}"
    echo -e "${RED}Check if the PID is correct and try running this script with sudo/root access.${NC}"
    echo
fi

read -p "Press ENTER to exit..."
exit 0
