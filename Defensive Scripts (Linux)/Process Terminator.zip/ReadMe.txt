README MANUAL - CYBER GARDEN DEFENSIVE SCRIPTS (LINUX EDITION)
--------------------------------------------------------------

1. Make the script executable using the following command:
      chmod +x scriptname.sh

2. Run the script using sudo to provide elevated privileges:
      sudo ./scriptname.sh

3. If there is any suspicious program, review it carefully. If it is unknown, terminate it. Otherwise, keep it after confirming the legitimacy.

    - Option 1: [Recommended]
        * Note down the PID value related to the suspicious process shown in the script output.
        * Run the process terminator script from Cyber Garden.
        * Type the noted PID and continue.
        * Process will be terminated.

    - Option 2:
        * Note down the process name.
        * Open the terminal and run:
              ps aux | grep processname
        * Identify the correct process and run:
              sudo kill -9 PID
        * Process will be terminated.

4. If there is any malicious program, or if it is well known or confirmed as harmful, terminate it immediately.

        * Follow the same instructions above to terminate.

5. If there is any suspicious document, review it carefully. If it is unknown, delete it. Otherwise, keep it after confirming the legitimacy.

        * Scan results of the relevant scripts will include file paths of suspicious or malicious files.

6. If there is any malicious document, or if it is verified as dangerous, delete it immediately.

7. For the Bad USB detector, run the script first and then plug in the suspicious USB storage device.

8. Before running the Macro File Detector, make sure you have a proper internet connection.

9. For the phishing analyzer, place your email file (.eml) into the Phishing Analyzer folder.

        * Download the email from your mail client.
        * Place the .eml file inside the Phishing Analyzer folder.
        * Run the script.

10. For the smishing analyzer, put your suspicious message into a file named message.txt inside the Smishing Analyzer folder.

11. For the vishing analyzer, provide accurate call details and review the suspicious score and mitigation methods shown by the script.

12. Find more information in the user manual available on the official Cyber Garden website.

13. Visit the Cyber Garden website for user awareness sessions and video tutorials for the defensive scripts.

14. Stay tuned with Cyber Garden.
