#!/bin/bash

# Eye on Smishing - Smishing Analyzer
# A Social Engineering Defence Tool from the Cyber Garden Project

clear

# Load banner
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BANNER_FILE="$SCRIPT_DIR/banner.txt"

if [[ -f "$BANNER_FILE" ]]; then
    cat "$BANNER_FILE"
else
    echo "[!] Banner file not found."
fi

echo
echo "                          Eye on Smishing - Smishing Analyzer"
echo
echo "----------------------------------------------------------------------------------------"
echo

# Pre-execution rules
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
NC='\033[0m'

echo -e "${YELLOW}Please carefully follow these rules BEFORE running the detection:${NC}"
echo
echo "1. Put the suspicious SMS message as a .txt file (excluding banner.txt) in the same folder."
echo "2. Close ALL running applications and background programs to reduce noise."
echo "3. Disable automatic cloud sync or backup software temporarily."
echo "4. Run this script with sudo/root privileges for full access."
echo "5. Do not modify any file name related to the program."
echo
read -p "Press ENTER to confirm you have completed these steps and want to proceed..."

clear

# === Stage 1: Smishing Analysis ===
echo -e "${CYAN}[ Stage 1 ] Smishing Analysis${NC}"
echo

# Find first .txt file excluding banner.txt
message_file=$(find "$SCRIPT_DIR" -maxdepth 1 -type f -iname "*.txt" ! -iname "banner.txt" | head -n 1)

if [[ -z "$message_file" ]]; then
    echo -e "\033[1;31m[ Alert ] No SMS message file found. Please place a .txt file (excluding 'banner.txt') in the same folder.\033[0m"
    echo
    exit 1
fi

echo -e "[  Alert  ] Loaded message from: $(basename "$message_file")"
message_content=$(cat "$message_file")
echo

# Initialize score
score=0

# Detection Rules
declare -A rules
rules=(
    ["Urgency or Threats"]="urgent(ly)?|immediately|act now|last chance|limited time|time is running|final warning"
    ["Prize or Free Offer"]="you[’']?ve won|congratulations|free (gift|offer|voucher)|claim (now|your prize)|lucky winner|exclusive reward|win big"
    ["Account or Service Issues"]="account (locked|suspended|blocked)|verify account|reset password|unauthorized login|security alert|unusual activity|confirm details"
    ["Bank or Financial Terms"]="bank (account|statement|alert)|credit card|debit card|transaction alert|payment failure|balance check|refund processed"
    ["Suspicious or Shortened Links"]="https?://(bit\.ly|tinyurl\.com|t\.co|shorturl|is\.gd|rb\.gy|.*\.ru/|.*\.tk/)"
    ["Requests for Personal Info"]="provide (otp|password|credentials|security code)|confirm ssn|share account details|login info|personal data|identity verification"
    ["Refunds or Unauthorized Charges"]="you have been (charged|billed)|unauthorized purchase|refund available|payment error|billing discrepancy|chargeback notice"
    ["Impersonation of Authority"]="irs|police|court notice|fbi|gov(ernment)?|official warning|legal action"
    ["Poor Spelling or Grammar"]="recieve|immediatly|urgnt|verfy|confrim|click hear|congrtulations|plese respond"
    ["Secrecy or Isolation Requests"]="don't tell anyone|keep this secret|do not share|for your eyes only|only you can access"
)

# Apply rules
for rule in "${!rules[@]}"; do
    if echo "$message_content" | grep -Eiq "${rules[$rule]}"; then
        echo -e "\033[1;33m[  Alert  ] Rule Triggered: $rule\033[0m"
        score=$((score + 10))
    fi
done

# === Stage 2: Result ===
echo
echo -e "${CYAN}[ Stage 2 ] Analysis Result${NC}"
echo
echo -e "[  Alert  ] Suspicion Score: $score%"

if ((score < 20)); then
    echo -e "\033[1;32m[  Alert  ] Risk Level: LOW RISK - Safe, but Remain Vigilant.\033[0m"
elif ((score < 40)); then
    echo -e "\033[1;33m[  Alert  ] Risk Level: MEDIUM RISK - Potentially Suspicious. Please Verify the legitimacy.\033[0m"
elif ((score < 70)); then
    echo -e "\033[1;35m[  Alert  ] Risk Level: HIGH RISK - Likely Smishing. Do Not interact.\033[0m"
else
    echo -e "\033[1;31m[  Alert  ] Risk Level: CRITICAL - Confirmed Smishing Attack. Take Immediate Action.\033[0m"
fi

# === Stage 3: Mitigation Methods ===
echo
echo -e "${CYAN}[ Stage 3 ] Mitigation Methods${NC}"
echo
cat << EOF
1. If the message claims to be from a known organization, confirm through official channels.
2. Do not click suspicious links. Use Cyber Garden's online scanning tools.
3. If any file is included or mentioned, scan it using antivirus or macro detector.
4. Never reply to messages asking for sensitive information unless verified.
5. Avoid installing apps or opening files from SMS messages unless trusted.
6. Never share banking details, OTPs, or passwords via SMS.
7. Do not respond to messages using urgency or threats to manipulate you.
8. Ignore prize claims, refunds, or alert messages unless confirmed legitimate.
9. Report any suspicious SMS to your IT team, telecom provider, or local authority.
10. Keep your phone, OS, and security apps updated regularly.
EOF

echo
read -p "Press ENTER to exit..."
