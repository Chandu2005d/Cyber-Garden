#!/bin/bash

# Eye on USB - USB Autorun Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

# ====================== CONFIG ======================
SUS_EXTENSIONS=("*.inf" "*.exe" "*.bat" "*.cmd" "*.scr" "*.vbs" "*.lnk" "*.sh" "*.pif" "*.com" "*.msi" "*.jar" "*.ps1")
LOG_FILE="/tmp/eyeonusb.log"
SCAN_DIR="/media/kali"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
NC='\033[0m'

# ====================== FUNCTIONS ======================

log_event() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

scan_for_suspicious_files() {
    local scan_path="$1"
    local found_files=0
    
    echo -e "${CYAN}[SCANNING] Checking $scan_path for suspicious files.${NC}"
    
    if [[ ! -d "$scan_path" ]]; then
        echo -e "${YELLOW}[INFO] Directory $scan_path does not exist${NC}"
        return 0
    fi
    
    # Show what's in the directory
    echo -e "${BLUE}[INFO] Contents of $scan_path:${NC}"
    ls -la "$scan_path" 2>/dev/null
    
    # Count total files
    local total_files=$(find "$scan_path" -type f 2>/dev/null | wc -l)
    echo -e "${BLUE}[INFO] Total files to scan: $total_files${NC}"
    
    if [[ $total_files -eq 0 ]]; then
        echo -e "${GREEN}[OK] No files found${NC}"
        return 0
    fi
    
    # Scan for suspicious extensions
    for ext in "${SUS_EXTENSIONS[@]}"; do
        while IFS= read -r -d '' file; do
            if [[ -f "$file" ]]; then
                echo -e "${RED}[SUSPICIOUS] $file${NC}"
                echo -e "${YELLOW}  Size: $(stat -c%s "$file" 2>/dev/null) bytes${NC}"
                log_event "SUSPICIOUS FILE: $file"
                ((found_files++))
            fi
        done < <(find "$scan_path" -type f -iname "$ext" -print0 2>/dev/null)
    done
    
    # Check for autorun files
    while IFS= read -r -d '' autorun_file; do
        echo -e "${RED}[AUTORUN] $autorun_file${NC}"
        echo -e "${YELLOW}Contents:${NC}"
        cat "$autorun_file" 2>/dev/null
        log_event "AUTORUN FILE: $autorun_file"
        ((found_files++))
    done < <(find "$scan_path" -type f -iname "autorun.*" -print0 2>/dev/null)
    
    # Summary
    if [[ $found_files -eq 0 ]]; then
        echo -e "${GREEN}[CLEAN] No suspicious files found${NC}"
    else
        echo -e "${RED}[WARNING] Found $found_files suspicious file(s)!${NC}"
    fi
    
    return $found_files
}

# ====================== MAIN SCRIPT ======================

clear
echo -e "${CYAN}Eye on USB - Simple USB Detector${NC}"
echo -e "${BLUE}Monitoring for USB devices...${NC}"
echo -e "${BLUE}Will scan: $SCAN_DIR${NC}"
echo -e "${BLUE}Log file: $LOG_FILE${NC}"
echo "----------------------------------------"

# Check if we can access the scan directory
if [[ ! -d "$SCAN_DIR" ]]; then
    echo -e "${YELLOW}[WARNING] $SCAN_DIR does not exist, will create when needed${NC}"
fi

log_event "USB Detection Started"

# Listen for USB devices
udevadm monitor --subsystem-match=usb --udev | while read -r line; do
    if echo "$line" | grep -qi "add"; then
        echo -e "\n${YELLOW}[DETECTED] USB device connected!${NC}"
        
        # Get USB device info
        usb_info=$(lsusb | tail -1)
        echo -e "${GREEN}Device: $usb_info${NC}"
        log_event "USB DETECTED: $usb_info"
        
        # Wait 10 seconds for mounting
        echo -e "${BLUE}[WAITING] Waiting 10 seconds for device to mount.${NC}"
        for i in {10..1}; do
            echo -n "$i "
            sleep 1
        done
        echo
        
        # Now scan /media/kali/
        echo -e "${CYAN}[SCANNING] Scanning $SCAN_DIR${NC}"
        scan_for_suspicious_files "$SCAN_DIR"
        
        echo -e "\n${CYAN}[DONE] Scan complete. Waiting for next USB device...${NC}"
        echo "========================================================"
        log_event "SCAN COMPLETED"
    fi
done
