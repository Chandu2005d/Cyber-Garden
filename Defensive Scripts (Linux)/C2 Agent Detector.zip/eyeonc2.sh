#!/bin/bash

# Eye on C2 - C2 Agent Detector
# A Social Engineering Defence Tool from the Cyber Garden Project

# ====== CONFIG ======

# Load banner
BANNER_FILE="$(dirname "$0")/banner.txt"
[[ -f "$BANNER_FILE" ]] && cat "$BANNER_FILE"
echo "                       Eye on C2 - C2 Agent Detector"
echo
echo "--------------------------------------------------------------------------------"
echo

# ====== INSTRUCTIONS ======
echo -e "\e[33mPlease carefully follow these rules BEFORE running the detection:\e[0m"
echo
echo "1. Close ALL applications and background services to reduce noise."
echo "2. Temporarily disable auto-sync, updates, and cloud services."
echo "3. Run this script with sudo for full access to process info."
echo "4. Do not rename any core files related to this tool."
echo "5. Kill any malicious process using process termiantor tool."
echo
read -rp "Press ENTER to confirm you have completed these steps and want to proceed..."

clear
echo -e "\n\e[36m[Stage 1] Scanning outgoing network connections.\e[0m"
echo

# ====== SAFE PROCESS LIST ======
SAFE_PROCESSES=(
  systemd NetworkManager dbus-daemon sshd cron rsyslogd systemd-journald
  bash zsh fish sh sudo gnome-shell gdm-x-session Xorg lightdm sddm
  firefox firefox-esr chromium brave qutebrowser
  curl wget apt apt-get dpkg snap flatpak
  code code-insiders nano vim neovim
  spotify discord signal whatsapp telegram-desktop slack zoom skype
  docker containerd dockerd kubelet podman
  openvpn openvpn3 wireguard wg-quick tailscaled
  nm-applet blueman-applet
)

# ====== MALICIOUS PROCESS KEYWORDS ======
MALICIOUS_KEYWORDS=(
  metasploit meterpreter cobaltstrike sliver beacon havoc r77shell
  xrat njrat darkcomet poisonivy remcos agent teslacrypt lokibot
  rootkit botnet miner scanrat spykey evilx pupyre interpreter
  backdoor dropper inject snoop camgrab micgrab
)

# Lowercase helper
tolower() {
  echo "$1" | tr '[:upper:]' '[:lower:]'
}

# Check if process is safe
is_safe_process() {
  local target=$(tolower "$1")
  for safe in "${SAFE_PROCESSES[@]}"; do
    [[ "$target" == "$(tolower "$safe")" ]] && return 0
  done
  return 1
}

# Check if process matches malicious keyword
is_malicious_process() {
  local target=$(tolower "$1")
  for keyword in "${MALICIOUS_KEYWORDS[@]}"; do
    if [[ "$target" == *"$keyword"* ]]; then
      return 0
    fi
  done
  return 1
}

# ====== CONNECTION SCANNING ======
ss -tunap | grep ESTAB > /tmp/connections.tmp

if [[ ! -s /tmp/connections.tmp ]]; then
  echo -e "\e[31m[-] No ESTABLISHED connections found.\e[0m"
  exit 1
fi

# ====== ANALYZE CONNECTIONS ======
while read -r line; do
  proto=$(echo "$line" | awk '{print $1}')
  local_addr=$(echo "$line" | awk '{print $5}')
  remote_addr=$(echo "$line" | awk '{print $6}')
  pid_prog=$(echo "$line" | awk -F 'pid=' '{print $2}' | cut -d',' -f1)
  process_name="unknown"

  if [[ -n "$pid_prog" ]]; then
    process_name=$(ps -p "$pid_prog" -o comm= 2>/dev/null)
  fi

  # Skip if we couldn't find process name
  if [[ -z "$process_name" ]]; then
    continue
  fi

  # Determine verdict
  verdict="Suspicious"
  if is_safe_process "$process_name"; then
    verdict="Safe"
  elif is_malicious_process "$process_name"; then
    verdict="Malicious"
  fi

  # Output with color
  case $verdict in
    Safe)
      echo -e "\e[32m[SAFE]        PID: $pid_prog - $process_name\e[0m"
      ;;
    Suspicious)
      echo -e "\e[33m[SUSPICIOUS]  PID: $pid_prog - $process_name\e[0m"
      ;;
    Malicious)
      echo -e "\e[31m[MALICIOUS]   PID: $pid_prog - $process_name\e[0m"
      ;;
  esac

  echo "    Remote Address: $remote_addr"
  echo
done < /tmp/connections.tmp

# ====== CLEANUP ======
rm -f /tmp/connections.tmp

echo "-------------------------------------------------------------"
read -rp "Press ENTER to exit..."
